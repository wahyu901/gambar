package com.example.autosketch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import java.io.File
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

class DrawService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var preview: PreviewView? = null
    private var plp: WindowManager.LayoutParams? = null
    private var paths: List<List<PointF>> = emptyList()
    private var aspect = 1f
    private var stop = false
    private val ui = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stop = true }

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val p = LinearLayout(this).apply { setBackgroundColor(0xCC000000.toInt()) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 11f; setOnClickListener { f() }; p.addView(this, LinearLayout.LayoutParams(-2, -2))
        }
        btn("MUAT") { load() }
        btn("−") { resize(0.85f) }
        btn("+") { resize(1.18f) }
        btn("GAMBAR") { draw() }
        btn("STOP") { stop = true }
        val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        wm.addView(p, lp)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun load() {
        val f = File(cacheDir, "in.jpg")
        val bmp = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
        if (bmp == null) { toast("Pilih foto dulu di aplikasi AutoSketch"); return }
        toast("Memproses...")
        Thread {
            val r = trace(bmp)
            ui.post { paths = r; aspect = bmp.height / bmp.width.toFloat(); showPreview(); toast("${r.size} goresan") }
        }.start()
    }

    private fun showPreview() {
        preview?.let { wm.removeView(it) }
        val w = (resources.displayMetrics.widthPixels * 0.7f).toInt()
        val lp = WindowManager.LayoutParams(w, (w * aspect).toInt(), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (resources.displayMetrics.widthPixels - w) / 2; lp.y = 300
        val v = PreviewView(this, paths)
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
                MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(v, lp) }
            }
            true
        }
        wm.addView(v, lp); preview = v; plp = lp
    }

    private fun resize(k: Float) {
        val v = preview ?: return; val lp = plp ?: return
        lp.width = (lp.width * k).toInt(); lp.height = (lp.height * k).toInt()
        wm.updateViewLayout(v, lp)
    }

    private fun draw() {
        val v = preview ?: run { toast("Tekan MUAT dulu"); return }
        val lp = plp!!
        val ox = lp.x.toFloat(); val oy = lp.y.toFloat(); val pw = lp.width.toFloat(); val ph = lp.height.toFloat()
        wm.removeView(v); preview = null; stop = false
        ui.postDelayed({ next(0, ox, oy, pw, ph) }, 300)
    }

    private fun next(i: Int, ox: Float, oy: Float, pw: Float, ph: Float) {
        if (stop || i >= paths.size) { toast(if (stop) "Dihentikan" else "Selesai"); return }
        val pts = paths[i]
        val path = Path()
        pts.forEachIndexed { k, p ->
            val x = ox + p.x * pw; val y = oy + p.y * ph
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val dur = (pts.size * 5L).coerceAtLeast(30)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        val cb = object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { next(i + 1, ox, oy, pw, ph) }
            override fun onCancelled(d: GestureDescription?) { next(i + 1, ox, oy, pw, ph) }
        }
        if (!dispatchGesture(g, cb, null)) toast("Gesture gagal")
    }

    /** Sobel + non-max suppression, lalu rangkai piksel tepi jadi polyline (koordinat 0..1). */
    private fun trace(bmp: Bitmap): List<List<PointF>> {
        val s = 300f / max(bmp.width, bmp.height)
        val w = (bmp.width * s).toInt(); val h = (bmp.height * s).toInt()
        val px = IntArray(w * h)
        Bitmap.createScaledBitmap(bmp, w, h, true).getPixels(px, 0, w, 0, 0, w, h)
        val g = FloatArray(w * h) { 0.3f * Color.red(px[it]) + 0.59f * Color.green(px[it]) + 0.11f * Color.blue(px[it]) }
        val mag = FloatArray(w * h); val horiz = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val dx = (g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1]) - (g[i - w - 1] + 2 * g[i - 1] + g[i + w - 1])
            val dy = (g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]) - (g[i - w - 1] + 2 * g[i - w] + g[i - w + 1])
            mag[i] = hypot(dx, dy); horiz[i] = abs(dx) > abs(dy)
        }
        val edge = BooleanArray(w * h)
        for (y in 2 until h - 2) for (x in 2 until w - 2) {
            val i = y * w + x
            if (mag[i] < THRESH) continue
            val a = if (horiz[i]) i - 1 else i - w; val b = if (horiz[i]) i + 1 else i + w
            edge[i] = mag[i] >= mag[a] && mag[i] >= mag[b]
        }
        val vis = BooleanArray(w * h); val out = ArrayList<List<PointF>>()
        for (st in edge.indices) {
            if (!edge[st] || vis[st]) continue
            val p = ArrayList<PointF>(); var c = st
            while (true) {
                vis[c] = true; p.add(PointF((c % w) / w.toFloat(), (c / w) / h.toFloat()))
                var n = -1
                loop@ for (dy in -1..1) for (dx in -1..1) {
                    val j = c + dy * w + dx
                    if (edge[j] && !vis[j]) { n = j; break@loop }
                }
                if (n < 0) break; c = n
            }
            if (p.size >= MIN_LEN) out.add(p)
        }
        return out
    }

    class PreviewView(c: Context, ps: List<List<PointF>>) : View(c) {
        private val path = Path().apply { ps.forEach { l -> l.forEachIndexed { k, p -> if (k == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y) } } }
        private val paint = Paint().apply { color = Color.RED; style = Paint.Style.STROKE; strokeWidth = 0f }
        init { setBackgroundColor(0x44FFFFFF) }
        override fun onDraw(c: Canvas) { c.scale(width.toFloat(), height.toFloat()); c.drawPath(path, paint) }
    }

    companion object { const val THRESH = 90f; const val MIN_LEN = 12 }
}
