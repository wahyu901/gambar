package com.example.autosketch

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        l.addView(TextView(this).apply {
            text = "1. Aktifkan layanan 'AutoSketch' di Aksesibilitas\n2. Pilih foto\n3. Buka SketchBook, tekan MUAT di panel mengambang, seret/ubah ukuran pratinjau ke kanvas, tekan GAMBAR"
        })
        l.addView(Button(this).apply {
            text = "Buka Pengaturan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        l.addView(Button(this).apply {
            text = "Pilih Foto"
            setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1) }
        })
        setContentView(l)
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        val u = d?.data ?: return
        contentResolver.openInputStream(u)?.use { i ->
            File(cacheDir, "in.jpg").outputStream().use { i.copyTo(it) }
        }
        Toast.makeText(this, "Foto tersimpan. Buka SketchBook lalu tekan MUAT.", Toast.LENGTH_LONG).show()
    }
}
